# CS224-Markov
# Markov Chain Project
# Create two shell scripts that will generate random sentences from input text.
